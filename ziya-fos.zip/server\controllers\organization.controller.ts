import { Response } from "express";
import jwt from "jsonwebtoken";

import prisma from "../config/prisma";
import { AuthRequest } from "../middleware/auth.middleware";

/* =========================================================
   JWT CONFIGURATION
========================================================= */

function getJwtSecret(): string {
  const secret =
    process.env.JWT_SECRET?.trim();

  if (!secret) {
    throw new Error(
      "JWT_SECRET is not configured."
    );
  }

  return secret;
}

/* =========================================================
   TENANT CONTEXT
========================================================= */

function getTenantContext(
  req: AuthRequest
): {
  userId: string;
  organizationId: string;
} | null {
  if (!req.user) {
    return null;
  }

  if (
    req.user.sessionType !== "TENANT"
  ) {
    return null;
  }

  if (
    !req.user.userId ||
    !req.user.organizationId
  ) {
    return null;
  }

  return {
    userId: req.user.userId,
    organizationId:
      req.user.organizationId,
  };
}

/* =========================================================
   GET USER ORGANIZATIONS

   GET /api/organizations

   Returns ONLY organizations where the authenticated user:
   - has an OrganizationMember record
   - has an active membership
   - belongs to an active organization

   PLATFORM_ADMIN does not automatically receive access.
========================================================= */

export const getOrganizations = async (
  req: AuthRequest,
  res: Response
) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        code: "AUTH_REQUIRED",
        message:
          "Authentication required.",
      });
    }

    if (
      req.user.sessionType !== "TENANT"
    ) {
      return res.status(403).json({
        success: false,
        code:
          "TENANT_SESSION_REQUIRED",
        message:
          "A tenant session is required to access organizations.",
      });
    }

    const memberships =
      await prisma.organizationMember.findMany({
        where: {
          userId:
            req.user.userId,

          isActive: true,

          organization: {
            status: "ACTIVE",
          },
        },

        select: {
          id: true,
          role: true,
          permissions: true,
          isDefault: true,
          joinedAt: true,

          organization: {
            select: {
              id: true,
              name: true,
              slug: true,
              legalName: true,
              registrationNumber: true,
              taxNumber: true,
              email: true,
              phoneNumber: true,
              address: true,
              country: true,
              currency: true,
              logoUrl: true,
              status: true,
            },
          },
        },

        orderBy: [
          {
            isDefault: "desc",
          },
          {
            joinedAt: "asc",
          },
        ],
      });

    const organizations =
      memberships.map(
        (membership) => ({
          ...membership.organization,

          membership: {
            id: membership.id,
            role: membership.role,

            permissions:
              membership.permissions ??
              [],

            isDefault:
              membership.isDefault,

            joinedAt:
              membership.joinedAt,
          },

          /*
           * Allows the frontend to identify the workspace
           * currently represented by the JWT.
           */
          isCurrent:
            membership.organization.id ===
            req.user?.organizationId,
        })
      );

    return res.status(200).json({
      success: true,

      currentOrganizationId:
        req.user.organizationId,

      organizations,
    });
  } catch (error) {
    console.error(
      "[ORGANIZATION] List error:",
      error
    );

    return res.status(500).json({
      success: false,
      code:
        "ORGANIZATION_LIST_FAILED",
      message:
        "Unable to retrieve organizations.",
    });
  }
};

/* =========================================================
   GET CURRENT ORGANIZATION

   GET /api/organizations/current

   The organization is taken ONLY from the authenticated
   tenant session.

   Request parameters cannot override organizationId.
========================================================= */

export const getCurrentOrganization = async (
  req: AuthRequest,
  res: Response
) => {
  try {
    const context =
      getTenantContext(req);

    if (!context) {
      return res.status(403).json({
        success: false,
        code:
          "TENANT_SESSION_REQUIRED",
        message:
          "A tenant session is required.",
      });
    }

    const membership =
      await prisma.organizationMember.findUnique({
        where: {
          userId_organizationId: {
            userId:
              context.userId,

            organizationId:
              context.organizationId,
          },
        },

        select: {
          id: true,
          role: true,
          permissions: true,
          isActive: true,
          isDefault: true,
          joinedAt: true,

          user: {
            select: {
              id: true,
              isActive: true,
              platformRole: true,
            },
          },

          organization: {
            select: {
              id: true,
              name: true,
              slug: true,
              legalName: true,
              registrationNumber: true,
              taxNumber: true,
              email: true,
              phoneNumber: true,
              address: true,
              country: true,
              currency: true,
              logoUrl: true,
              status: true,
              createdAt: true,
              updatedAt: true,
            },
          },
        },
      });

    if (!membership) {
      return res.status(403).json({
        success: false,
        code:
          "ORGANIZATION_ACCESS_DENIED",
        message:
          "You do not have access to this organization.",
      });
    }

    if (
      !membership.user.isActive
    ) {
      return res.status(403).json({
        success: false,
        code: "ACCOUNT_DISABLED",
        message:
          "Your account has been disabled.",
      });
    }

    if (
      membership.user.platformRole
    ) {
      return res.status(403).json({
        success: false,
        code:
          "PLATFORM_ACCOUNT_RESTRICTED",
        message:
          "Platform administration accounts cannot access tenant financial workspaces.",
      });
    }

    if (
      !membership.isActive
    ) {
      return res.status(403).json({
        success: false,
        code:
          "MEMBERSHIP_DISABLED",
        message:
          "Your access to this organization has been disabled.",
      });
    }

    if (
      membership.organization.status !==
      "ACTIVE"
    ) {
      return res.status(403).json({
        success: false,
        code:
          "ORGANIZATION_DISABLED",
        message:
          "This organization is not currently active.",
      });
    }

    return res.status(200).json({
      success: true,

      organization:
        membership.organization,

      membership: {
        id:
          membership.id,

        role:
          membership.role,

        permissions:
          membership.permissions ??
          [],

        isDefault:
          membership.isDefault,

        joinedAt:
          membership.joinedAt,
      },
    });
  } catch (error) {
    console.error(
      "[ORGANIZATION] Fetch error:",
      error
    );

    return res.status(500).json({
      success: false,
      code:
        "ORGANIZATION_FETCH_FAILED",
      message:
        "Unable to retrieve organization.",
    });
  }
};

/* =========================================================
   SWITCH ORGANIZATION

   POST /api/organizations/switch

   SECURITY RULE:

   organizationId from the request is NEVER trusted by
   itself.

   Before issuing another tenant JWT we prove:

   1. User exists.
   2. User is active.
   3. User is not a platform administration identity.
   4. Membership exists.
   5. Membership belongs to requested organization.
   6. Membership is active.
   7. Organization is active.

   Only then is a new tenant token issued.
========================================================= */

export const switchOrganization = async (
  req: AuthRequest,
  res: Response
) => {
  try {
    if (!req.user) {
      return res.status(401).json({
        success: false,
        code: "AUTH_REQUIRED",
        message:
          "Authentication required.",
      });
    }

    if (
      req.user.sessionType !== "TENANT"
    ) {
      return res.status(403).json({
        success: false,
        code:
          "TENANT_SESSION_REQUIRED",
        message:
          "A tenant session is required.",
      });
    }

    const organizationId =
      typeof req.body?.organizationId ===
      "string"
        ? req.body.organizationId.trim()
        : "";

    if (!organizationId) {
      return res.status(400).json({
        success: false,
        code:
          "ORGANIZATION_REQUIRED",
        message:
          "Organization ID is required.",
      });
    }

    /* =====================================================
       VERIFY REQUESTED MEMBERSHIP
    ===================================================== */

    const membership =
      await prisma.organizationMember.findUnique({
        where: {
          userId_organizationId: {
            userId:
              req.user.userId,

            organizationId,
          },
        },

        select: {
          id: true,
          role: true,
          permissions: true,
          isActive: true,
          isDefault: true,

          user: {
            select: {
              id: true,
              isActive: true,
              platformRole: true,
            },
          },

          organization: {
            select: {
              id: true,
              name: true,
              slug: true,
              legalName: true,
              logoUrl: true,
              country: true,
              currency: true,
              status: true,
            },
          },
        },
      });

    if (!membership) {
      return res.status(403).json({
        success: false,
        code:
          "ORGANIZATION_ACCESS_DENIED",
        message:
          "You do not have access to the selected organization.",
      });
    }

    /* =====================================================
       USER MUST BE ACTIVE
    ===================================================== */

    if (
      !membership.user.isActive
    ) {
      return res.status(403).json({
        success: false,
        code: "ACCOUNT_DISABLED",
        message:
          "Your account has been disabled.",
      });
    }

    /* =====================================================
       PLATFORM ACCOUNT PROTECTION
    ===================================================== */

    if (
      membership.user.platformRole
    ) {
      return res.status(403).json({
        success: false,
        code:
          "PLATFORM_ACCOUNT_RESTRICTED",
        message:
          "Platform administration accounts cannot access tenant financial workspaces.",
      });
    }

    /* =====================================================
       MEMBERSHIP MUST BE ACTIVE
    ===================================================== */

    if (
      !membership.isActive
    ) {
      return res.status(403).json({
        success: false,
        code:
          "MEMBERSHIP_DISABLED",
        message:
          "Your access to the selected organization has been disabled.",
      });
    }

    /* =====================================================
       ORGANIZATION MUST BE ACTIVE
    ===================================================== */

    if (
      membership.organization.status !==
      "ACTIVE"
    ) {
      return res.status(403).json({
        success: false,
        code:
          "ORGANIZATION_DISABLED",
        message:
          "The selected organization is not currently active.",
      });
    }

    /* =====================================================
       ISSUE NEW TENANT JWT

       Membership has now been proven.

       The new organizationId and role therefore come from
       the database rather than arbitrary client claims.
    ===================================================== */

    const token =
      jwt.sign(
        {
          userId:
            membership.user.id,

          sessionType:
            "TENANT",

          organizationId:
            membership.organization.id,

          role:
            membership.role,
        },

        getJwtSecret(),

        {
          expiresIn: "1d",
        }
      );

    return res.status(200).json({
      success: true,

      message:
        "Organization switched successfully.",

      token,

      organization: {
        id:
          membership.organization.id,

        name:
          membership.organization.name,

        slug:
          membership.organization.slug,

        legalName:
          membership.organization
            .legalName,

        logoUrl:
          membership.organization
            .logoUrl,

        country:
          membership.organization
            .country,

        currency:
          membership.organization
            .currency,
      },

      membership: {
        id:
          membership.id,

        role:
          membership.role,

        permissions:
          membership.permissions ??
          [],

        isDefault:
          membership.isDefault,
      },
    });
  } catch (error) {
    console.error(
      "[ORGANIZATION] Switch error:",
      error
    );

    return res.status(500).json({
      success: false,
      code:
        "ORGANIZATION_SWITCH_FAILED",
      message:
        "Unable to switch organization.",
    });
  }
};